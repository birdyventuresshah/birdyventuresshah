# Says "This was CS50"

import pyttsx3

engine = pyttsx3.init()
engine.say("This was CS50")
engine.runAndWait()
