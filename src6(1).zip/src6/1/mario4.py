# Prints a row of 4 question marks with a loop

for i in range(4):
    print("?", end="")
print()
