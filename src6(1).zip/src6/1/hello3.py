# input and print, with format strings

answer = input("What's your name? ")
print(f"hello, {answer}")
