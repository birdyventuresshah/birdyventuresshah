# Prints a column of 3 bricks with a loop

for i in range(3):
    print("#")
