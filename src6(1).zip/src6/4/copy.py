# Capitalizes a copy of a string

from cs50 import get_string

# Get a string
s = get_string("s: ")

# Capitalize copy of string
t = s.capitalize()

# Print strings
print(f"s: {s}")
print(f"t: {t}")
